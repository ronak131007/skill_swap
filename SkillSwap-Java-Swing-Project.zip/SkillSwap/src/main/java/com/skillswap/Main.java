package com.skillswap;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import org.mindrot.jbcrypt.BCrypt;

public class Main {
    private static final Color NAVY = new Color(27, 39, 69);
    private static final Color BLUE = new Color(55, 105, 190);
    private static final Color BG = new Color(245, 247, 251);
    private static JFrame frame;
    private static User current;

    record User(int id, String name, String email, String role) {}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) {}
            showLogin();
        });
    }

    private static void showLogin() {
        frame = new JFrame("SkillSwap | Sign in");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(470, 440); frame.setLocationRelativeTo(null);
        JPanel root = new JPanel(new GridBagLayout()); root.setBackground(BG);
        JPanel card = new JPanel(); card.setLayout(new BoxLayout(card,BoxLayout.Y_AXIS));
        card.setBackground(Color.WHITE); card.setBorder(new EmptyBorder(28,35,28,35));
        JLabel title = new JLabel("SkillSwap"); title.setFont(new Font("SansSerif",Font.BOLD,30)); title.setForeground(NAVY);
        JLabel sub = new JLabel("Learn together. Grow together."); sub.setForeground(Color.GRAY);
        JTextField email = field("Email address"); JPasswordField pass = new JPasswordField(); pass.setBorder(BorderFactory.createTitledBorder("Password"));
        JButton login = button("Sign in"); JButton register = linkButton("Create a student account");
        card.add(title); card.add(Box.createVerticalStrut(5)); card.add(sub); card.add(Box.createVerticalStrut(25));
        card.add(email); card.add(Box.createVerticalStrut(12)); card.add(pass); card.add(Box.createVerticalStrut(18)); card.add(login); card.add(register);
        root.add(card); frame.setContentPane(root);
        login.addActionListener(e -> {
            try {
                User u = authenticate(email.getText().trim(),new String(pass.getPassword()));
                if (u==null) msg("Invalid email or password.");
                else { current=u; showDashboard(); }
            } catch(Exception ex) { error(ex); }
        });
        register.addActionListener(e -> showRegister());
        frame.setVisible(true);
    }

    private static void showRegister() {
        JTextField name=field("Full name"), email=field("Email address");
        JPasswordField p1=new JPasswordField(), p2=new JPasswordField();
        p1.setBorder(BorderFactory.createTitledBorder("Password (minimum 8 characters)"));
        p2.setBorder(BorderFactory.createTitledBorder("Confirm password"));
        JPanel panel=new JPanel(new GridLayout(0,1,8,8));
        panel.add(name);panel.add(email);panel.add(p1);panel.add(p2);
        int result=JOptionPane.showConfirmDialog(frame,panel,"Create SkillSwap account",JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE);
        if(result!=JOptionPane.OK_OPTION)return;
        String password=new String(p1.getPassword());
        if(name.getText().isBlank()||email.getText().isBlank()||!email.getText().contains("@")||password.length()<8||!password.equals(new String(p2.getPassword()))) {
            msg("Enter valid details. Passwords must match and contain at least 8 characters."); return;
        }
        try(Connection c=DB.get();PreparedStatement ps=c.prepareStatement(
                "INSERT INTO users(name,email,password_hash) VALUES(?,?,?)")) {
            ps.setString(1,name.getText().trim());ps.setString(2,email.getText().trim().toLowerCase());
            ps.setString(3,BCrypt.hashpw(password,BCrypt.gensalt(12)));ps.executeUpdate();
            msg("Account created. You can now sign in.");
        } catch(SQLException ex){error(ex);}
    }

    private static User authenticate(String email,String password)throws Exception {
        try(Connection c=DB.get();PreparedStatement p=c.prepareStatement("SELECT * FROM users WHERE email=?")) {
            p.setString(1,email.toLowerCase());
            try(ResultSet r=p.executeQuery()) {
                if(r.next()&&BCrypt.checkpw(password,r.getString("password_hash")))
                    return new User(r.getInt("user_id"),r.getString("name"),r.getString("email"),r.getString("role"));
            }
        }
        return null;
    }

    private static void showDashboard() {
        frame.dispose(); frame=new JFrame("SkillSwap | "+current.name()); frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1120,720);frame.setLocationRelativeTo(null);
        JPanel root=new JPanel(new BorderLayout());root.setBackground(BG);
        JPanel side=new JPanel();side.setBackground(NAVY);side.setPreferredSize(new Dimension(215,0));side.setLayout(new BoxLayout(side,BoxLayout.Y_AXIS));side.setBorder(new EmptyBorder(22,14,18,14));
        JLabel brand=new JLabel("  SkillSwap");brand.setForeground(Color.WHITE);brand.setFont(new Font("SansSerif",Font.BOLD,24));side.add(brand);
        JLabel user=new JLabel("  "+current.name());user.setForeground(new Color(205,215,235));user.setBorder(new EmptyBorder(12,0,22,0));side.add(user);
        JPanel content=new JPanel(new BorderLayout());content.setBackground(BG);
        JLabel heading=new JLabel("Welcome, "+current.name());heading.setFont(new Font("SansSerif",Font.BOLD,23));heading.setBorder(new EmptyBorder(22,24,16,10));content.add(heading,BorderLayout.NORTH);
        JPanel body=new JPanel(new BorderLayout());body.setBackground(BG);body.setBorder(new EmptyBorder(0,24,22,24));content.add(body,BorderLayout.CENTER);
        addNav(side,"Overview",()->showOverview(body));
        addNav(side,"My Skills",()->showSkills(body));
        addNav(side,"Find Matches",()->showMatches(body));
        addNav(side,"Requests",()->showRequests(body));
        addNav(side,"Learning Sessions",()->showSessions(body));
        addNav(side,"Reviews",()->showReviews(body));
        addNav(side,"Notifications",()->showNotifications(body));
        if("ADMIN".equals(current.role()))addNav(side,"Admin Panel",()->showAdmin(body));
        side.add(Box.createVerticalGlue());addNav(side,"Sign out",()->{current=null;frame.dispose();showLogin();});
        root.add(side,BorderLayout.WEST);root.add(content,BorderLayout.CENTER);frame.setContentPane(root);
        showOverview(body);frame.setVisible(true);
    }

    private static void addNav(JPanel side,String label,Runnable action) {
        JButton b=new JButton(label);b.setMaximumSize(new Dimension(190,40));b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setForeground(Color.WHITE);b.setBackground(NAVY);b.setFocusPainted(false);b.setBorder(new EmptyBorder(10,12,10,8));b.setFont(new Font("SansSerif",Font.PLAIN,14));
        b.addActionListener(e->action.run());side.add(b);
    }
    private static void setBody(JPanel body,JComponent component){body.removeAll();body.add(component,BorderLayout.CENTER);body.revalidate();body.repaint();}
    private static JPanel page(){JPanel p=new JPanel(new BorderLayout(12,12));p.setBackground(BG);return p;}
    private static void showOverview(JPanel body) {
        JPanel p=page();JPanel cards=new JPanel(new GridLayout(1,3,14,14));cards.setBackground(BG);
        try {
            cards.add(statCard("My skills",count("SELECT COUNT(*) FROM user_skills WHERE user_id=?",current.id()),"Teach and learn"));
            cards.add(statCard("Requests",count("SELECT COUNT(*) FROM skill_requests WHERE sender_id=? OR receiver_id=?",current.id(),current.id()),"Exchange requests"));
            cards.add(statCard("Sessions",count("SELECT COUNT(*) FROM sessions s JOIN skill_requests r ON s.request_id=r.request_id WHERE r.sender_id=? OR r.receiver_id=?",current.id(),current.id()),"Learning sessions"));
        }catch(Exception ex){error(ex);}
        JPanel info=new JPanel(new BorderLayout());info.setBackground(Color.WHITE);info.setBorder(new EmptyBorder(22,22,22,22));
        JLabel h=new JLabel("Make learning a two-way journey");h.setFont(new Font("SansSerif",Font.BOLD,19));
        JTextArea t=new JTextArea("1. Add skills you can teach and skills you want to learn.\\n2. Discover students with complementary skills.\\n3. Send a request and arrange a learning session.\\n4. Complete the session and exchange feedback.");t.setEditable(false);t.setFont(new Font("SansSerif",Font.PLAIN,15));t.setBackground(Color.WHITE);t.setBorder(new EmptyBorder(15,0,0,0));
        info.add(h,BorderLayout.NORTH);info.add(t,BorderLayout.CENTER);p.add(cards,BorderLayout.NORTH);p.add(info,BorderLayout.CENTER);setBody(body,p);
    }
    private static JPanel statCard(String label,int value,String desc){JPanel p=new JPanel();p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));p.setBackground(Color.WHITE);p.setBorder(new EmptyBorder(18,20,18,20));JLabel a=new JLabel(label);a.setForeground(Color.GRAY);JLabel n=new JLabel(""+value);n.setFont(new Font("SansSerif",Font.BOLD,30));n.setForeground(BLUE);JLabel d=new JLabel(desc);d.setForeground(Color.GRAY);p.add(a);p.add(Box.createVerticalStrut(8));p.add(n);p.add(d);return p;}

    private static void showSkills(JPanel body) {
        JPanel p=page();JPanel top=new JPanel(new FlowLayout(FlowLayout.LEFT));top.setBackground(BG);
        JButton teach=button("Add skill to TEACH"),learn=button("Add skill to LEARN"),remove=button("Remove selected");
        top.add(teach);top.add(learn);top.add(remove);p.add(top,BorderLayout.NORTH);
        DefaultTableModel m=model("ID","Skill","Category","Type","Proficiency");JTable table=new JTable(m);loadSkills(m,current.id());
        p.add(new JScrollPane(table),BorderLayout.CENTER);
        teach.addActionListener(e->addSkill("TEACH",m));learn.addActionListener(e->addSkill("LEARN",m));
        remove.addActionListener(e->{int row=table.getSelectedRow();if(row<0){msg("Select a skill first.");return;}try(Connection c=DB.get();PreparedStatement q=c.prepareStatement("DELETE FROM user_skills WHERE id=? AND user_id=?")){q.setInt(1,(int)m.getValueAt(row,0));q.setInt(2,current.id());q.executeUpdate();loadSkills(m,current.id());}catch(Exception ex){error(ex);}});
        setBody(body,p);
    }
    private static void loadSkills(DefaultTableModel m,int uid){m.setRowCount(0);String sql="SELECT us.id,s.skill_name,s.category,us.skill_type,us.proficiency FROM user_skills us JOIN skills s ON s.skill_id=us.skill_id WHERE us.user_id=? ORDER BY s.skill_name";try(Connection c=DB.get();PreparedStatement q=c.prepareStatement(sql)){q.setInt(1,uid);try(ResultSet r=q.executeQuery()){while(r.next())m.addRow(new Object[]{r.getInt(1),r.getString(2),r.getString(3),r.getString(4),r.getString(5)});}}catch(Exception ex){error(ex);}}
    private static void addSkill(String type,DefaultTableModel m) {
        try {
            java.util.List<String> names=new ArrayList<>();try(Connection c=DB.get();Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT skill_name FROM skills ORDER BY skill_name")){while(r.next())names.add(r.getString(1));}
            String name=(String)JOptionPane.showInputDialog(frame,"Choose a skill","Add "+type+" skill",JOptionPane.PLAIN_MESSAGE,null,names.toArray(),names.isEmpty()?null:names.get(0));
            if(name==null)return;
            String[] levels={"Beginner","Intermediate","Advanced"};String level=(String)JOptionPane.showInputDialog(frame,"Your proficiency","Proficiency",JOptionPane.PLAIN_MESSAGE,null,levels,levels[0]);
            if(level==null)return;
            try(Connection c=DB.get();PreparedStatement q=c.prepareStatement("INSERT INTO user_skills(user_id,skill_id,skill_type,proficiency) SELECT ?,skill_id,?,? FROM skills WHERE skill_name=? ON DUPLICATE KEY UPDATE proficiency=VALUES(proficiency)")){
                q.setInt(1,current.id());q.setString(2,type);q.setString(3,level);q.setString(4,name);q.executeUpdate();
            }loadSkills(m,current.id());
        }catch(Exception ex){error(ex);}
    }

    private static void showMatches(JPanel body) {
        JPanel p=page();JLabel note=new JLabel("Students with complementary teach/learn skills");note.setBorder(new EmptyBorder(0,0,8,0));p.add(note,BorderLayout.NORTH);
        DefaultTableModel m=model("Student ID","Student","Can teach","Wants to learn","Match score");JTable table=new JTable(m);
        String sql="SELECT u.user_id,u.name,GROUP_CONCAT(DISTINCT CASE WHEN mine.skill_type='TEACH' THEN sm.skill_name END) teach,GROUP_CONCAT(DISTINCT CASE WHEN theirs.skill_type='TEACH' THEN st.skill_name END) learn FROM users u JOIN user_skills theirs ON theirs.user_id=u.user_id JOIN skills st ON st.skill_id=theirs.skill_id LEFT JOIN user_skills mine ON mine.user_id=? LEFT JOIN skills sm ON sm.skill_id=mine.skill_id WHERE u.user_id<>? GROUP BY u.user_id,u.name";
        try(Connection c=DB.get();PreparedStatement q=c.prepareStatement(sql)){q.setInt(1,current.id());q.setInt(2,current.id());try(ResultSet r=q.executeQuery()){while(r.next()){int uid=r.getInt(1);String name=r.getString(2);String teach=r.getString(3)==null?"":r.getString(3);String learn=r.getString(4)==null?"":r.getString(4);int score=matchScore(current.id(),uid);if(score>0)m.addRow(new Object[]{uid,name,teach,learn,score+"%"});}}}catch(Exception ex){error(ex);}
        JButton request=button("Send learning request");request.addActionListener(e->{int row=table.getSelectedRow();if(row<0){msg("Select a match.");return;}int target=(int)m.getValueAt(row,0);String message=JOptionPane.showInputDialog(frame,"Write a short introduction:","Hi! I'd like to exchange skills with you.");if(message==null)return;try(Connection c=DB.get();PreparedStatement q=c.prepareStatement("INSERT INTO skill_requests(sender_id,receiver_id,message) VALUES(?,?,?)")){q.setInt(1,current.id());q.setInt(2,target);q.setString(3,message);q.executeUpdate();DB.notifyUser(target,current.name()+" sent you a skill exchange request.");msg("Request sent.");}catch(Exception ex){error(ex);}});
        JPanel bottom=new JPanel(new FlowLayout(FlowLayout.LEFT));bottom.setBackground(BG);bottom.add(request);p.add(new JScrollPane(table),BorderLayout.CENTER);p.add(bottom,BorderLayout.SOUTH);setBody(body,p);
    }
    private static int matchScore(int a,int b)throws SQLException {
        String sql="SELECT COUNT(*) FROM user_skills a JOIN user_skills b ON a.skill_id=b.skill_id WHERE a.user_id=? AND b.user_id=? AND a.skill_type='LEARN' AND b.skill_type='TEACH'";
        int x=scalar(sql,a,b);String reverse="SELECT COUNT(*) FROM user_skills a JOIN user_skills b ON a.skill_id=b.skill_id WHERE a.user_id=? AND b.user_id=? AND a.skill_type='TEACH' AND b.skill_type='LEARN'";
        int y=scalar(reverse,a,b);return Math.min(100,(x+y)*50);
    }

    private static void showRequests(JPanel body) {
        JPanel p=page();DefaultTableModel m=model("ID","From","To","Message","Status","Created");JTable table=new JTable(m);
        String sql="SELECT r.request_id,s.name,t.name,r.message,r.status,r.created_at FROM skill_requests r JOIN users s ON s.user_id=r.sender_id JOIN users t ON t.user_id=r.receiver_id WHERE r.sender_id=? OR r.receiver_id=? ORDER BY r.created_at DESC";
        try(Connection c=DB.get();PreparedStatement q=c.prepareStatement(sql)){q.setInt(1,current.id());q.setInt(2,current.id());try(ResultSet r=q.executeQuery()){while(r.next())m.addRow(new Object[]{r.getInt(1),r.getString(2),r.getString(3),r.getString(4),r.getString(5),r.getTimestamp(6)});}}catch(Exception ex){error(ex);}
        JPanel actions=new JPanel(new FlowLayout(FlowLayout.LEFT));actions.setBackground(BG);JButton accept=button("Accept"),reject=button("Reject");
        accept.addActionListener(e->updateRequest(table,m,"ACCEPTED"));reject.addActionListener(e->updateRequest(table,m,"REJECTED"));
        actions.add(accept);actions.add(reject);p.add(new JScrollPane(table),BorderLayout.CENTER);p.add(actions,BorderLayout.SOUTH);setBody(body,p);
    }
    private static void updateRequest(JTable table,DefaultTableModel m,String status){int row=table.getSelectedRow();if(row<0){msg("Select a request.");return;}int id=(int)m.getValueAt(row,0);try(Connection c=DB.get();PreparedStatement q=c.prepareStatement("UPDATE skill_requests SET status=? WHERE request_id=? AND receiver_id=? AND status='PENDING'")){q.setString(1,status);q.setInt(2,id);q.setInt(3,current.id());if(q.executeUpdate()==0)msg("Only pending requests addressed to you can be updated.");else{msg("Request "+status.toLowerCase()+".");showDashboardRefresh();}}catch(Exception ex){error(ex);}}
    private static void showDashboardRefresh(){showDashboard();}

    private static void showSessions(JPanel body) {
        JPanel p=page();JPanel top=new JPanel(new FlowLayout(FlowLayout.LEFT));top.setBackground(BG);JButton schedule=button("Schedule accepted request"),complete=button("Mark completed");top.add(schedule);top.add(complete);
        DefaultTableModel m=model("Session ID","Request ID","Partner","Scheduled at","Minutes","Status");JTable table=new JTable(m);loadSessions(m);
        schedule.addActionListener(e->scheduleSession());complete.addActionListener(e->{int row=table.getSelectedRow();if(row<0){msg("Select a session.");return;}try(Connection c=DB.get();PreparedStatement q=c.prepareStatement("UPDATE sessions s JOIN skill_requests r ON s.request_id=r.request_id SET s.status='COMPLETED' WHERE s.session_id=? AND (r.sender_id=? OR r.receiver_id=?)")){q.setInt(1,(int)m.getValueAt(row,0));q.setInt(2,current.id());q.setInt(3,current.id());q.executeUpdate();loadSessions(m);}catch(Exception ex){error(ex);}});
        p.add(top,BorderLayout.NORTH);p.add(new JScrollPane(table),BorderLayout.CENTER);setBody(body,p);
    }
    private static void loadSessions(DefaultTableModel m){m.setRowCount(0);String sql="SELECT s.session_id,r.request_id,CASE WHEN r.sender_id=? THEN u2.name ELSE u1.name END,s.scheduled_at,s.duration_minutes,s.status FROM sessions s JOIN skill_requests r ON s.request_id=r.request_id JOIN users u1 ON r.sender_id=u1.user_id JOIN users u2 ON r.receiver_id=u2.user_id WHERE r.sender_id=? OR r.receiver_id=? ORDER BY s.scheduled_at DESC";try(Connection c=DB.get();PreparedStatement q=c.prepareStatement(sql)){q.setInt(1,current.id());q.setInt(2,current.id());q.setInt(3,current.id());try(ResultSet r=q.executeQuery()){while(r.next())m.addRow(new Object[]{r.getInt(1),r.getInt(2),r.getString(3),r.getTimestamp(4),r.getInt(5),r.getString(6)});}}catch(Exception ex){error(ex);}}
    private static void scheduleSession(){try{java.util.List<String> reqs=new ArrayList<>();Map<String,Integer> ids=new HashMap<>();String sql="SELECT request_id,sender_id,receiver_id FROM skill_requests WHERE status='ACCEPTED' AND (sender_id=? OR receiver_id=?) AND request_id NOT IN(SELECT request_id FROM sessions)";try(Connection c=DB.get();PreparedStatement q=c.prepareStatement(sql)){q.setInt(1,current.id());q.setInt(2,current.id());try(ResultSet r=q.executeQuery()){while(r.next()){String label="Request #"+r.getInt(1);reqs.add(label);ids.put(label,r.getInt(1));}}}if(reqs.isEmpty()){msg("No accepted requests available to schedule.");return;}String selected=(String)JOptionPane.showInputDialog(frame,"Choose request","Schedule session",JOptionPane.PLAIN_MESSAGE,null,reqs.toArray(),reqs.get(0));if(selected==null)return;String date=JOptionPane.showInputDialog(frame,"Date and time (yyyy-MM-dd HH:mm)","2026-12-01 14:00");if(date==null)return;LocalDateTime dt=LocalDateTime.parse(date,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));String mins=JOptionPane.showInputDialog(frame,"Duration in minutes","60");int duration=Integer.parseInt(mins);if(duration<15||duration>480)throw new IllegalArgumentException("Duration must be 15–480 minutes.");try(Connection c=DB.get();PreparedStatement q=c.prepareStatement("INSERT INTO sessions(request_id,scheduled_at,duration_minutes) VALUES(?,?,?)")){q.setInt(1,ids.get(selected));q.setTimestamp(2,Timestamp.valueOf(dt));q.setInt(3,duration);q.executeUpdate();msg("Session scheduled.");}}catch(Exception ex){error(ex);}}

    private static void showReviews(JPanel body) {
        JPanel p=page();DefaultTableModel m=model("Review ID","Session","Reviewer","Rating","Feedback","Date");JTable table=new JTable(m);
        String sql="SELECT rv.review_id,rv.session_id,u.name,rv.rating,rv.feedback,rv.created_at FROM reviews rv JOIN users u ON u.user_id=rv.reviewer_id JOIN sessions s ON s.session_id=rv.session_id JOIN skill_requests r ON r.request_id=s.request_id WHERE r.sender_id=? OR r.receiver_id=? ORDER BY rv.created_at DESC";
        try(Connection c=DB.get();PreparedStatement q=c.prepareStatement(sql)){q.setInt(1,current.id());q.setInt(2,current.id());try(ResultSet r=q.executeQuery()){while(r.next())m.addRow(new Object[]{r.getInt(1),r.getInt(2),r.getString(3),r.getInt(4),r.getString(5),r.getTimestamp(6)});}}catch(Exception ex){error(ex);}
        JButton add=button("Write a review");add.addActionListener(e->writeReview());JPanel bottom=new JPanel(new FlowLayout(FlowLayout.LEFT));bottom.setBackground(BG);bottom.add(add);p.add(new JScrollPane(table),BorderLayout.CENTER);p.add(bottom,BorderLayout.SOUTH);setBody(body,p);
    }
    private static void writeReview(){try{java.util.List<Integer> ids=new ArrayList<>();java.util.List<String> labels=new ArrayList<>();String sql="SELECT s.session_id,r.sender_id,r.receiver_id,u1.name,u2.name FROM sessions s JOIN skill_requests r ON r.request_id=s.request_id JOIN users u1 ON u1.user_id=r.sender_id JOIN users u2 ON u2.user_id=r.receiver_id WHERE s.status='COMPLETED' AND (r.sender_id=? OR r.receiver_id=?) AND NOT EXISTS(SELECT 1 FROM reviews rv WHERE rv.session_id=s.session_id AND rv.reviewer_id=?)";try(Connection c=DB.get();PreparedStatement q=c.prepareStatement(sql)){q.setInt(1,current.id());q.setInt(2,current.id());q.setInt(3,current.id());try(ResultSet r=q.executeQuery()){while(r.next()){ids.add(r.getInt(1));labels.add("Session #"+r.getInt(1)+" with "+(r.getInt(2)==current.id()?r.getString(5):r.getString(4)));}}}if(ids.isEmpty()){msg("No completed sessions available for review.");return;}String selected=(String)JOptionPane.showInputDialog(frame,"Choose session","Review",JOptionPane.PLAIN_MESSAGE,null,labels.toArray(),labels.get(0));if(selected==null)return;int index=labels.indexOf(selected),sid=ids.get(index);String rating=JOptionPane.showInputDialog(frame,"Rating from 1 to 5","5");int score=Integer.parseInt(rating);if(score<1||score>5)throw new IllegalArgumentException("Rating must be 1–5.");String feedback=JOptionPane.showInputDialog(frame,"Feedback","Great learning session!");try(Connection c=DB.get();PreparedStatement q=c.prepareStatement("INSERT INTO reviews(session_id,reviewer_id,reviewee_id,rating,feedback) SELECT ?,?,?,?,?")){q.setInt(1,sid);q.setInt(2,current.id());q.setInt(3,sessionPartner(sid));q.setInt(4,score);q.setString(5,feedback==null?"":feedback);q.executeUpdate();DB.notifyUser(sessionPartner(sid),current.name()+" left you a review.");msg("Review submitted.");}}catch(Exception ex){error(ex);}}
    private static int sessionPartner(int sid)throws SQLException{try(Connection c=DB.get();PreparedStatement q=c.prepareStatement("SELECT sender_id,receiver_id FROM skill_requests r JOIN sessions s ON s.request_id=r.request_id WHERE s.session_id=?")){q.setInt(1,sid);try(ResultSet r=q.executeQuery()){if(r.next())return r.getInt(1)==current.id()?r.getInt(2):r.getInt(1);}}throw new SQLException("Session partner not found.");}

    private static void showNotifications(JPanel body){JPanel p=page();DefaultTableModel m=model("ID","Message","Read","Date");String sql="SELECT notification_id,message,is_read,created_at FROM notifications WHERE user_id=? ORDER BY created_at DESC";try(Connection c=DB.get();PreparedStatement q=c.prepareStatement(sql)){q.setInt(1,current.id());try(ResultSet r=q.executeQuery()){while(r.next())m.addRow(new Object[]{r.getInt(1),r.getString(2),r.getBoolean(3),r.getTimestamp(4)});}}catch(Exception ex){error(ex);}JTable table=new JTable(m);JButton read=button("Mark selected as read");read.addActionListener(e->{int row=table.getSelectedRow();if(row<0)return;try(Connection c=DB.get();PreparedStatement q=c.prepareStatement("UPDATE notifications SET is_read=TRUE WHERE notification_id=? AND user_id=?")){q.setInt(1,(int)m.getValueAt(row,0));q.setInt(2,current.id());q.executeUpdate();m.setValueAt(true,row,2);}catch(Exception ex){error(ex);}});JPanel b=new JPanel(new FlowLayout(FlowLayout.LEFT));b.setBackground(BG);b.add(read);p.add(new JScrollPane(table),BorderLayout.CENTER);p.add(b,BorderLayout.SOUTH);setBody(body,p);}

    private static void showAdmin(JPanel body){if(!"ADMIN".equals(current.role()))return;JPanel p=page();DefaultTableModel m=model("ID","Name","Email","Role","Created");try(Connection c=DB.get();Statement q=c.createStatement();ResultSet r=q.executeQuery("SELECT user_id,name,email,role,created_at FROM users ORDER BY created_at DESC")){while(r.next())m.addRow(new Object[]{r.getInt(1),r.getString(2),r.getString(3),r.getString(4),r.getTimestamp(5)});}catch(Exception ex){error(ex);}JTable t=new JTable(m);JButton refresh=button("Refresh users");refresh.addActionListener(e->showAdmin(body));p.add(new JScrollPane(t),BorderLayout.CENTER);p.add(refresh,BorderLayout.SOUTH);setBody(body,p);}

    private static int count(String sql,int... values)throws SQLException{try(Connection c=DB.get();PreparedStatement p=c.prepareStatement(sql)){for(int i=0;i<values.length;i++)p.setInt(i+1,values[i]);try(ResultSet r=p.executeQuery()){r.next();return r.getInt(1);}}}
    private static int scalar(String sql,int a,int b)throws SQLException{return count(sql,a,b);}
    private static JTextField field(String title){JTextField f=new JTextField();f.setBorder(BorderFactory.createTitledBorder(title));f.setPreferredSize(new Dimension(300,48));return f;}
    private static JButton button(String text){JButton b=new JButton(text);b.setBackground(BLUE);b.setForeground(Color.WHITE);b.setFocusPainted(false);b.setBorder(new EmptyBorder(10,15,10,15));return b;}
    private static JButton linkButton(String text){JButton b=new JButton(text);b.setBorderPainted(false);b.setContentAreaFilled(false);b.setForeground(BLUE);return b;}
    private static DefaultTableModel model(String... cols){return new DefaultTableModel(cols,0){public boolean isCellEditable(int r,int c){return false;}};}
    private static void msg(String s){JOptionPane.showMessageDialog(frame,s);}
    private static void error(Exception e){e.printStackTrace();JOptionPane.showMessageDialog(frame,"Operation failed: "+e.getMessage(),"SkillSwap",JOptionPane.ERROR_MESSAGE);}
}
