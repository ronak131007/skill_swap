package com.skillswap;

import java.sql.*;

public final class DB {
    private static final String URL = System.getenv().getOrDefault("SKILLSWAP_DB_URL",
            "jdbc:mysql://localhost:3306/skillswap?useSSL=false&serverTimezone=UTC");
    private static final String USER = System.getenv().getOrDefault("SKILLSWAP_DB_USER", "root");
    private static final String PASS = System.getenv().getOrDefault("SKILLSWAP_DB_PASSWORD", "root");

    private DB() {}
    public static Connection get() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
    public static void notifyUser(int userId, String message) {
        String sql = "INSERT INTO notifications(user_id,message) VALUES(?,?)";
        try (Connection c=get(); PreparedStatement p=c.prepareStatement(sql)) {
            p.setInt(1,userId); p.setString(2,message); p.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }
}
