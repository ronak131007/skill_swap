CREATE DATABASE IF NOT EXISTS skillswap CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE skillswap;

CREATE TABLE IF NOT EXISTS users (
 user_id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 password_hash VARCHAR(100) NOT NULL,
 role ENUM('STUDENT','ADMIN') NOT NULL DEFAULT 'STUDENT',
 bio VARCHAR(500) DEFAULT '',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS skills (
 skill_id INT AUTO_INCREMENT PRIMARY KEY,
 skill_name VARCHAR(100) NOT NULL UNIQUE,
 category VARCHAR(100) DEFAULT 'General'
);

CREATE TABLE IF NOT EXISTS user_skills (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 skill_id INT NOT NULL,
 skill_type ENUM('TEACH','LEARN') NOT NULL,
 proficiency VARCHAR(30) DEFAULT 'Beginner',
 UNIQUE KEY uq_user_skill_type(user_id,skill_id,skill_type),
 FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE CASCADE,
 FOREIGN KEY(skill_id) REFERENCES skills(skill_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS skill_requests (
 request_id INT AUTO_INCREMENT PRIMARY KEY,
 sender_id INT NOT NULL,
 receiver_id INT NOT NULL,
 message VARCHAR(500) DEFAULT '',
 status ENUM('PENDING','ACCEPTED','REJECTED') DEFAULT 'PENDING',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(sender_id) REFERENCES users(user_id),
 FOREIGN KEY(receiver_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS sessions (
 session_id INT AUTO_INCREMENT PRIMARY KEY,
 request_id INT NOT NULL UNIQUE,
 scheduled_at DATETIME NOT NULL,
 duration_minutes INT NOT NULL DEFAULT 60,
 status ENUM('SCHEDULED','COMPLETED','CANCELLED') DEFAULT 'SCHEDULED',
 FOREIGN KEY(request_id) REFERENCES skill_requests(request_id)
);

CREATE TABLE IF NOT EXISTS reviews (
 review_id INT AUTO_INCREMENT PRIMARY KEY,
 session_id INT NOT NULL,
 reviewer_id INT NOT NULL,
 reviewee_id INT NOT NULL,
 rating INT NOT NULL CHECK(rating BETWEEN 1 AND 5),
 feedback VARCHAR(1000) DEFAULT '',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_review(session_id,reviewer_id),
 FOREIGN KEY(session_id) REFERENCES sessions(session_id),
 FOREIGN KEY(reviewer_id) REFERENCES users(user_id),
 FOREIGN KEY(reviewee_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS notifications (
 notification_id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 message VARCHAR(500) NOT NULL,
 is_read BOOLEAN DEFAULT FALSE,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

INSERT IGNORE INTO skills(skill_name,category) VALUES
('Java','Programming'),('Python','Programming'),('C Programming','Programming'),
('C++','Programming'),('Web Design','Design'),('Graphic Design','Design'),
('SQL','Database'),('Excel','Productivity'),('Public Speaking','Communication'),
('Data Structures','Programming'),('Machine Learning','AI/ML'),('Photography','Creative');
