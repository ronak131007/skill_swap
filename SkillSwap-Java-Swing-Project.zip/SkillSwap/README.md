# SkillSwap — Java Swing + JDBC + MySQL

A Java desktop application for peer-to-peer skill exchange. Students list skills they can teach and want to learn, discover complementary matches, send requests, schedule sessions, and review completed sessions.

## Technology
- Java 17
- Java Swing (desktop GUI)
- JDBC + MySQL Connector/J
- MySQL 8+
- Maven
- jBCrypt for password hashing

> This is a desktop application, not a browser-hosted website. Swing provides the frontend; Java classes provide the application logic; MySQL stores the data.

## 1. Requirements
Install:
1. JDK 17 or later
2. MySQL Server 8+
3. IntelliJ IDEA or Eclipse
4. Maven (or use the IDE's bundled Maven)

## 2. Create the database
Open MySQL Workbench and run `database/skillswap.sql`.

## 3. Configure database credentials
The defaults in `DB.java` are:
- URL: `jdbc:mysql://localhost:3306/skillswap?useSSL=false&serverTimezone=UTC`
- username: `root`
- password: `root`

Change the defaults in `DB.java`, or set environment variables:
- `SKILLSWAP_DB_URL`
- `SKILLSWAP_DB_USER`
- `SKILLSWAP_DB_PASSWORD`

Never commit real production credentials to source control.

## 4. Run the application
From the project root:
```bash
mvn clean compile
mvn exec:java
```
Or open the project in IntelliJ as a Maven project and run `com.skillswap.Main`.

## 5. Create an admin account
Register a normal account through the app. Then, in MySQL Workbench, promote that account:
```sql
USE skillswap;
UPDATE users SET role='ADMIN' WHERE email='your-email@example.com';
```
Sign out and sign in again. The Admin Panel will appear.

## 6. Modules included
- Registration and login (BCrypt password hashes)
- Student dashboard and summary counts
- Teach / Learn skill management
- Complementary skill matching
- Skill exchange requests (send, accept, reject)
- Session scheduling and completion
- Reviews and ratings
- Notifications and mark-as-read
- Admin user listing

## 7. Notes and limitations
- This starter application uses a single Swing window and database-backed panels.
- Matching score is based on complementary teach/learn skill overlap, not an AI model.
- Sessions are scheduled by selecting an accepted request and entering a date/time in `yyyy-MM-dd HH:mm` format.
- For a production release, add stronger input validation, pagination, audit logging, database migrations, and more granular admin controls.
- Use HTTPS and a server-side API if you later convert this into a multi-user internet application. A desktop Swing app is installed and run on each user's computer; it does not itself provide a public website URL.
